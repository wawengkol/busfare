  <?php
      include("connect.php");
      include("getUID.php");

		//$id = 112;
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
        echo $id;
    }

		$sql = "SELECT * FROM travels WHERE id='$id'";
		$result = $conn->query($sql);
    $conn->close();

		if ($result->num_rows > 0) {
			while($row = $result->fetch_assoc()) {
				echo $row["name"];
				 $origin=$row["origin"];
         $destination=$row["destination"];

			}
		} else {
			echo "0 results";
		}


    echo "<br>".$origin;
    echo "<br>".$destination;

    $subdata=explode(", ",$origin);
    $subdata2=explode(",",$destination);
    echo "<br>".$subdata2[0];
?>
<!DOCTYPE html>
<html lang="en">
<html>
	<head>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta charset="utf-8">
		<link href="css/bootstrap.min.css" rel="stylesheet">
		<script src="js/bootstrap.min.js"></script>
		<script src="jquery.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  	<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>

		<title>DISTANCE</title>
	</head>

	<body>

<br><br>



 <p id="display"> </p>
  <p class="ukm"> </p>
   <p class="km"> </p>
 <p id="mar"></p>
<?php
//
// $number=$_COOKIE['km'];
// switch ($number) {
// case $number >=0 && $number <=10:
//  print "The number is between 0 and 10";
//  break;
//
//  case $number >=11 && $number <=20:
//  print "The number is between 11 and 20";
//  break;
//
//  default:
//  print "Your number is not between 0 and 20";
// }

 ?>


 <script>

         var orilat='<?=$subdata[0]?>';
         var orilong='<?=$subdata[1]?>';
         var deslat='<?=$subdata2[0]?>';
         var deslong='<?=$subdata2[1]?>';

           console.log(orilat);
           console.log(orilong);
           console.log(deslat);
           console.log(deslong);
           const response = new Response();
           var distance = document.getElementById("display");
           var key="&key=kAgkr6UYkJ1eS21HKdhGj0066ZlWS";
           var destinations="&destinations="+ orilat + ","+orilong + key;
           //var destinations="&destinations=8.660401146703332,123.42211312772952"+ key;
           var json="json?origins=";
           var datas=json + deslat +","+ deslong + destinations;


           //url="https://api.distancematrix.ai/maps/api/distancematrix/json?origins=8.54229,123.32806&destinations=8.586383055786664,123.34571595184086&key=kAgkr6UYkJ1eS21HKdhGj0066ZlWS";
           link="https://api.distancematrix.ai/maps/api/distancematrix/";
           url=link + datas;
           //console.log(url);
             fetch(url)
               .then(response => response.json())
                .then((data) => distance.innerHTML = data.rows[0].elements[0].distance.text);
               //.then(data => console.log(data.rows[0].elements[0].distance.text));
               //let km = await fetchData()

               fetch(url, {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
                },
                //body: "text=" + document.querySelector("p.ukm").innerText
              })
              .then(response => response.text())
              .then(data => document.querySelector("p.km").innerHTML = data);



         // let dt=document.getElementById("display").innerHTML;
         // console.log(dt);
         // let dt=distance;
 				 // const km=dt.split(" ");
 				 // let km0=km[0];
 				 // document.getElementById("mar").innerHTML = km0;
         </script>


		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	</body>
</html>
