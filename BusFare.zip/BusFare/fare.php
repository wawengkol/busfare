<?php


function fare($bal,$km,$id) {


		$lawaan=1.5;
		$polo=4.5;
		$san_pedro=8;
		$owaon=9.1;
		$larayan=8;
		$upper_sicayab=9.9;
		$sicayab=10.4;
		$minaog=13.2;
		$dipolog=17.6;

		//echo "<br>".$km. "<br>";
		if($km >= $lawaan && $km<$polo){
			$fare=5;

		}elseif ($km >= $polo && $km<$san_pedro) {
			$fare=10;

		}elseif ($km >=$san_pedro && $km<$owaon) {
			$fare=14;

		}elseif ($km >=$owaon && $km<$larayan) {
			$fare=17;

		}elseif ($km >=$larayan && $km<$upper_sicayab) {
			$fare=19;

		}elseif ($km>=$upper_sicayab && $km<$sicayab) {
			$fare=20;

		}elseif ($km>=$sicayab && $km<$minaog) {
			$fare=25;

		}elseif ($km>=$minaog && $km<$dipolog) {
			$fare=27;

		}else{
			$fare=35;

		}




      echo " ".$fare." = ";


		//$bal=balance();

        $int = intval($bal);
        $text=null;

        //echo "<br> balance:". $bal."<br>";
        $difference=$int-$fare;
				echo " ".$difference."<br>";
        $text=strval($difference);
				//echo "text: ".$text;


         //echo $id."<br>";






		 //return $text ." ". $fare;
  	return $text;

}




?>
