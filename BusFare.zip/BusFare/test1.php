<?php
    include("connect.php");
    $setNow = $_GET['set'];
    $uid = $_GET['id'];
    $name = $_GET['name'];

    $sql1 = "INSERT INTO travels (uid,name) VALUES ('$uid','$name')";
    if($setNow == "True"){
      mysqli_query($conn,$sql1);
    }
    echo mysqli_error($conn);
?>
