<?php
    require 'database.php';
    $id = null;
    if ( !empty($_GET['id'])) {
        $id = $_REQUEST['id'];
    }

    $subData = explode(" ",$id);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
    <link   href="css/bootstrap.min.css" rel="stylesheet">
    <script src="js/bootstrap.min.js"></script>
	<style>
		td.lf {
			padding-left: 15px;
			padding-top: 12px;
			padding-bottom: 12px;
		}


    html {
      font-family: Arial;
      display: inline-block;
      margin: 0px auto;
      text-align: center;
    }

    ul.topnav {
      list-style-type: none;
      margin: auto;
      padding: 0;
      overflow: hidden;
      background-color: #4CAF50;
      width: 90%;
    }

    ul.topnav li {float: left;}

    ul.topnav li a {
      display: block;
      color: white;
      text-align: center;
      padding: 14px 16px;
      text-decoration: none;
    }

    ul.topnav li a:hover:not(.active) {background-color: #3e8e41;}

    ul.topnav li a.active {background-color: #333;}

    ul.topnav li.right {float: right;}

    @media screen and (max-width: 600px) {
      ul.topnav li.right,
      ul.topnav li {float: none;}
    }

    .table {
      margin: auto;
      width: 90%;
    }

    thead {
      color: #FFFFFF;
    }

    .container{
          display: block;
          margin-top: 10%;
          margin-left: auto;
          margin-right: auto;
        }
    </style>
</head>

	<body>
    <br>
		<div>


<?php echo '<p>Card id: '.$subData[0];?>
  <br>
<?php echo '<p>latitude: '.$subData[1];?>
  <br>
<?php echo '<p>longitude: '.$subData[2];
?>
  <br>

<?php
$uID=$subData[0];
echo $uID;
 ?>

 <?php

 $mysqli = new mysqli('localhost', 'root', 'root', 'busfare');

 if($mysqli->connect_errno > 0){
     die('Unable to connect to database [' . $mysqli->connect_error . ']');
 }

 $sql = "SELECT * FROM users where rfid_number  = '".$uID."'";
 $result = $mysqli->query($sql);
 $mysqli->close();
 ?>
 <br><br><br>
   <h1 id="display"></h1>
 <div class="container">
          <div class="row">
              <h3>User Data Table</h3>

                <!-- <input id="lat" type="text" name="" value="<?php echo $subData[1] ?>"/>
                <input id="long" type="text" name="" value="<?php echo  $subData[2] ?>"/> -->
          </div>
          <div class="row">
 <table class="table table-striped table-bordered">
             <tr bgcolor="#10a0c5" color="#FFFFFF">
                 <th>name</th>
                 <th>rfid</th>
                 <th>balance</th>
                 <th>contact</th>
             </tr>
             <!-- PHP CODE TO FETCH DATA FROM ROWS-->
             <?php   // LOOP TILL END OF DATA
                 while($rows=$result->fetch_assoc())
                 {
              ?>
             <tr>
                 <!--FETCHING DATA FROM EACH
                     ROW OF EVERY COLUMN-->
                 <td><?php echo $rows['name'];?></td>
                 <td><?php echo $rows['rfid_number'];?></td>
                 <td><?php echo $rows['balance'];?></td>
                 <td><?php echo $rows['mobile_number'];?></td>
             </tr>
             <?php
                 }
              ?>

            </div>
      		</div> <!-- /container -->
		</div>
    <script type="text/javascript">
      const response = new Response();


      var distance = document.getElementById("display");
      var lat = document.getElementById("lat").value;
      var long = document.getElementById("long").value;


      fetch('https://api.distancematrix.ai/maps/api/distancematrix/json?origins=8.54229,123.32806&destinations=8.586383055786664,123.34571595184086&key=PlX4Tonue3HjNEq0bKmVstLy8Ej6L')
        .then(response => response.json())
        .then((data) => distance.innerText = data.rows[0].elements[0].distance.text);

    </script>


	</body>
</html>
