<?php
        // include('getUID.php');
        // sleep(5);
      	// include('fetchapi.php');
        //
        //
        //
        //
      	// 			$conn = new mysqli('localhost', 'root','root', 'busfare');
      	// 			// Check connection
      	// 			if ($conn->connect_error) {
      	// 				die("Connection failed: " . $conn->connect_error);
      	// 			}
        //
        //
      	// 					$sql1 = "UPDATE users SET balance='$text' WHERE rfid_number='$UIDresult' && users.rfid_number IN (SELECT travels.uid FROM travels)";
        //
      	// 					if ($conn->query($sql1) === TRUE) {
      	// 						echo "Record updated successfully";
      	// 					} else {
      	// 						echo "Error updating record: " . $conn->error;
      	// 					}
        //
      	// 					return 0;
        //
      	// 				$conn->close();






 ?>
