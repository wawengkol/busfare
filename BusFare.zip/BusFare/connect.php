
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "busfare";
   // Create connection
   $conn = new mysqli($servername, $username, $password, $dbname);
   // Check connection

   if ($conn->connect_error) {
       die("Database Connection failed: " . $conn->connect_error);
   }
   $last_id = mysqli_insert_id($conn);
?>
