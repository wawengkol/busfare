  <?php

      include("connect.php");
      $uid=$_GET['uid'];

      $sql = "SELECT * FROM users WHERE rfid_number='$uid'";
      $result = $conn->query($sql);


          if ($result->num_rows > 0) {
              $row = $result->fetch_assoc();
              $rfidnumber=$row["rfid_number"];
              $name=$row["name"];
              $sql1 = "INSERT INTO travels (uid,name) VALUES ('$uid','$name')";

              if($row["balance"]>=35){
                echo json_encode(array("access" =>True ));
                mysqli_query($conn,$sql1);
                $conn->close();
              }
              else{
                echo json_encode(array("access" =>False ));
              }
          }
          else {
                echo "0 results";
            }





?>
