<?php
	include("connect.php");
	// include('fare.php');
	$UIDresult=$_POST["UIDresult"];
	$lat_str=$_POST["lat_str"];
	$lng_str=$_POST["lng_str"];
	$destination=$lat_str.",".$lng_str;
	// $destination='8.618934326444297,123.37755784789611';


								 $Write="<?php $" . "UIDresult='" . $UIDresult . "'; ?>";
			 					file_put_contents('UIDContainer.php',$Write);


	$sql = "SELECT * FROM users WHERE rfid_number='$UIDresult'";
	$result = $conn->query($sql);


			if ($result->num_rows > 0) {
					$row = $result->fetch_assoc();
					$now = $row['id'];
				  // $sql1 = "UPDATE travels SET destination='".$destination."' WHERE uid = '".$UIDresult."' && date = (SELECT MAX(timestamp) FROM travels )";

					$sql1 = "UPDATE travels SET destination='$destination' WHERE uid='$UIDresult' ORDER BY id DESC LIMIT 1 ";
					//$sql1 ="UPDATE  travels SET     destination='".$destination."' WHERE   uid =(SELECT  uid FROM    travels WHERE   uid = '".$UIDresult."' ORDER BY date_time DESC LIMIT 1)";

					mysqli_query($conn,$sql1);
					$conn->close();

			}
			else {
						echo "0 results";
				}



				?>
