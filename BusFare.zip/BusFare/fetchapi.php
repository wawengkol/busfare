<?php
      include('connect.php');
      include('UIDContainer.php');
      include('fare.php');
      echo "<br>".$UIDresult."<br>";



             // GET THE BALANCE ANG RFID NUMBER

      $sql1 = "SELECT * FROM users WHERE rfid_number='$UIDresult'";
      $result = $conn->query($sql1);



          if ($result->num_rows > 0) {
              $row = $result->fetch_assoc();
              $bal= $row['balance'];
              $uid=$row['rfid_number'];

            }	else {
                  echo "0 results";
            }
            echo "<br> balance: ".$bal."<br>";
            //echo "<br>".$uid;
            //$conn->close();




            // KM VALUE

         $k= $_COOKIE['km'];
         $subkm=explode(" ",$k);
         $km=$subkm[0];
         // sleep(10);


         echo "<br> km 1:".$km."<br>";
         if($km != 'undefined'){

           echo "<br> km:".$km."<br>";
             echo "<br> balance: ".$bal." -";
             $text=fare($bal,$km,$uid);
             echo "<br> balance remaining: ".$text."<br>";


                       // UPDATE BALANCE

            			// Check connection
            			if ($conn->connect_error) {
            				die("Connection failed: " . $conn->connect_error);
            			}


            					$sql1 = "UPDATE users SET balance='$text' WHERE rfid_number='$UIDresult' && users.rfid_number IN (SELECT travels.uid FROM travels)";

            					if ($conn->query($sql1) === TRUE) {
            						echo "Record updated successfully";
            					} else {
            						echo "Error updating record: " . $conn->error;
            					}

            					return 0;

            				$conn->close();


         } elseif($km == 'undefined'){
           $url1=$_SERVER['REQUEST_URI'];
           header("Refresh: 5; URL=$url1");
         }else {
          echo "error";
         }


              // GET LAT AND LONG

         $sql2 = "SELECT * FROM travels WHERE uid='$uid'";
         $result2 = $conn->query($sql2);
             if ($result2->num_rows > 0) {
                 $rows2 = $result2->fetch_assoc();
                  $origin= $rows2['origin'];
                  $destination=$rows2['destination'];
                  echo $origin;
                  echo $destination;
               }	else {
                     echo "0 results";
               }
               $conn->close();
                       // echo "<br>".$origin;
                       // echo "<br>".$destination;

            $suborigin=explode(",",$origin);
            $subdestination=explode(",",$destination);

                echo "<br>".$orilat=$suborigin[0];
                echo "<br>".$orilng=$suborigin[1];
                echo "<br>".$deslat=$subdestination[0];
                echo "<br>".$deslng=$subdestination[1];


?>


<!-- GET KM VALUE FROM API -->

<!-- <script type="text/javascript">


      <?php echo "var orilat ='$orilat';";?>
      <?php echo "var orilng ='$orilng';";?>
      <?php echo "var deslat ='$deslat';";?>
      <?php echo "var deslng ='$deslng';";?>

      var url="https://api.distancematrix.ai/maps/api/distancematrix/json?origins=" + orilat +","+ orilng + "&destinations=" +deslat+","+deslng+ "&key=kAgkr6UYkJ1eS21HKdhGj0066ZlWS";


       //url='https://api.distancematrix.ai/maps/api/distancematrix/json?origins=8.660222209088326,123.42211414551483&destinations=8.618934326444297,123.37755784789611&departure_time=now&key=kAgkr6UYkJ1eS21HKdhGj0066ZlWS';

      console.log(url);

      !async function(){
      let data = await fetch(url)
          .then((response) => response.json())
          .then(data => {
              return data.rows[0].elements[0].distance.text;
          })
          .catch(error => {
              console.error(error);
          });


      console.log(data);
      document.cookie =  'km=' + data;


}();


</script> -->
